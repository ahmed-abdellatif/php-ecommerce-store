
<?php
// used to get mysql database connection
class Database{
	private $host = "siteground343.com";
	private $db_name = "ameabdel_ecom";
	private $username = "ameabdel_ahmed";
	private $password = "Berry123$?";
	public $conn;

	// get the database connection
	public function getConnection(){

		$this->conn = null;

		try{
			$this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
		}catch(PDOException $exception){
			echo "Connection error: " . $exception->getMessage();
		}

		return $this->conn;
	}
}
?>
