<?php
// just to show php information for debugging
phpinfo();
?>